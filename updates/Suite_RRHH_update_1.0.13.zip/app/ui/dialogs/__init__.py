"""Dialogos reutilizables."""
