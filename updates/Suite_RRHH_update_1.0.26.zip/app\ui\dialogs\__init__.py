"""Dialogos reutilizables."""
